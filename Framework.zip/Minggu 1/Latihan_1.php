<?php

class Buku {
    public $judul, 
           $pengarang, 
           $penerbit, 
           $tahun_terbit, 
           $cetakan;
}